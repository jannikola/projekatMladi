<?php

$q = mysqli_query($conn,"select * from news");


?>

<html>
<head>
<meta charset="utf-8">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<title></title>
</head>

<body>
<?php
 while($rw=mysqli_fetch_object($q)){
?>
<div class="summx" id="<?php echo $rw->id; ?>">
<a href="indexTest.php?mid=2&nid=<?php echo $rw->id; ?>">
   
    <div class="summ" >
        
        <h2><?php echo $rw->title; ?></h2>
        <img src="<?php echo "img/".$rw->img1; ?>" alt="logo" height="42" width="42">
        <p>
            <?php echo $rw->summary; ?>
        </p>
        <!--
                    <div class="LreadMore"><p><i class="fas fa-ellipsis-h"></i></p></div>
                    <div class ="Lopis" style="border:1px solid red;display:none">
                        <p>neki opis</p>
                    <div class="Lexit"><i class="fas fa-times-circle"></i></div>
                    </div>
        -->
    </div>
  </a>  
 </div>
<?php
 }
?>
  
     <!--
    <script>
        $("#leftbox").click(function(){$("#rightbox").css({"display":"none"})});
        $("#leftbox").click(function(){$(this).css({"display":"none"})});
        $("#leftbox").click(function(){$("#leftFull").css({"display":"block"})});
    </script>
    -->
   
</body>

</html>
