   <?php

    $default_page = (isset($_GET['mid']))?$_GET['mid']:1;
    $pages = array(
        "1"=>"pages/pocetna.php",
        "2"=>"pages/vijesti.php",
        "3"=>"pages/projekti.php",
        "4"=>"pages/aktivnosti.php",
        "5"=>"pages/omladinskaPolitika.php",
        "6"=>"pages/linkovi.php",
        "7"=>"pages/kontakti.php",
        "10"=>"pages/oNama.php"
    );

    if(isset($pages[$default_page])){
        require $pages[$default_page];
    }else{
        include $pages['1'];
    }
    /*
    if(isset($_GET['mid'])&&$_GET['mid']==="1"){
        include $pages['1'];
    } if(isset($_GET['mid'])&&$_GET['mid']==="2"){
        include $pages['2'];
    } if(isset($_GET['mid'])&&$_GET['mid']==="3"){
        include $pages['3'];
    } if(isset($_GET['mid'])&&$_GET['mid']==="4"){
        include $pages['4'];
    } if(isset($_GET['mid'])&&$_GET['mid']==="5"){
        include $pages['5'];
    } if(isset($_GET['mid'])&&$_GET['mid']==="6"){
        include $pages['6'];
    } if(isset($_GET['mid'])&&$_GET['mid']==="7"){
        include $pages['7'];
    } if(isset($_GET['mid'])&&$_GET['mid']==="10"){
        include $pages['8'];
    }
    */
                        
?>