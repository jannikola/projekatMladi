/*
$("#stan2").mouseenter(function(){$("#stan2x").css({"display":"block"}).css({"width":915})}).mouseleave(function(){$("#stan2x").css({"display":"none"})});
*/

//$("#sazetak").mouseenter(function(){$("#opis").css("display":"block")});

//$("#sazetak").mouseenter(function(){$("#opis").css({"display":"block"}));

/*
$(".LreadMore").click(function(){$(".Lopis").css({"display":"block"})});
$(".RreadMore").click(function(){$(".Ropis").css({"display":"block"})});
$(".LreadMore").click(function(){$(this).css({"display":"none"})});
$(".RreadMore").click(function(){$(this).css({"display":"none"})});
$(".Lexit").click(function(){$(".Lopis").css({"display":"none"})});
$(".Rexit").click(function(){$(".Ropis").css({"display":"none"})});
$(".Lexit").click(function(){$(".LreadMore").css({"display":"block"})});
$(".Rexit").click(function(){$(".RreadMore").css({"display":"block"})});
*/