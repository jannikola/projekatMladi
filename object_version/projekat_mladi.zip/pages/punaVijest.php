<?php

$id = $_GET['nid'];
$q = mysqli_query($conn,"select * from news where id=$id");
while($rw=mysqli_fetch_object($q)){



?>

  <div id="full">
        
        <h2><?php echo $rw->title; ?></h2>
            <img src="<?php echo "img/".$rw->img1; ?>" alt="logo" height="42" width="42">
            <p>
               <?php echo $rw->full_text; ?>
            </p>
            
    </div>

    

<?php
}
?>