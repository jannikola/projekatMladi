<?php
define("DB","projekatMladi");
define("DBHOST","localhost");
define("DBUSER","root");
define("DBPASS","");