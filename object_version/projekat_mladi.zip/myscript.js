/*
$("#stan1").mouseenter(function(){$(this).css({"width":915}).css({"height":600})}).mouseleave(function(){$(this).css({"width":300}).css({"height":300})}).click(function(){$("#stan1x").css({"display":"block"}).css({"width":915})});
//mouseenter(function(){$("#stan2x").css({"display":"block"})
*/
function dissapear(){
    $("#formLog").css({"display":"none"})
};
dissapear();
