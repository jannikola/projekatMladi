<?php
echo "hello from o nama";