<?php
echo "hello from linkovi";