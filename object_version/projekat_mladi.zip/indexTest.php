<?php
require "config.php";
$conn = mysqli_connect(DBHOST,DBUSER,DBPASS,DB);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Istočno Sarajevo</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Merriweather" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Great+Vibes" rel="stylesheet">
<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
<link href="css/styleTest.css" type="text/css" rel="stylesheet">
</head>

<body>
    

    <div id="wrapper">
        <div id="header">
            <h1>Omladinski savjet Istočna Ilidža</h1>
        </div>
        <div id="navigation">
            <ul>
                <?php
                        $q = mysqli_query($conn,"select * from navigation");
                        while($rw=mysqli_fetch_object($q)){
                ?>
                <li><a href="indexTest.php?mid=<?php echo $rw->id?>"><?php echo $rw->name; ?></a></li>
                <?php
                        }
                ?>
            </ul>
        </div>
        <div id="main">
            <div id="vijest" >
               
                    <?php require "view.php";
                    if(isset($_GET['nid'])){
                        ?>
                        <script>
                            function dissapear(){
                                $(".summx").css({"display":"none"});
                            }
                            dissapear();
                        </script>
                        <?php
                        include "pages/punaVijest.php";
                    }
                     ?>
            </div>
            
            
        </div>
        <div id="sidebar">
        <a href="https://www.accuweather.com/en/ba/banja-luka/35546/weather-forecast/35546" class="aw-widget-legal">
<!--
By accessing and/or using this code snippet, you agree to AccuWeather’s terms and conditions (in English) which can be found at https://www.accuweather.com/en/free-weather-widgets/terms and AccuWeather’s Privacy Statement (in English) which can be found at https://www.accuweather.com/en/privacy.
-->
</a><div id="awcc1527712675766" class="aw-widget-current"  data-locationkey="" data-unit="c" data-language="en-us" data-useip="true" data-uid="awcc1527712675766"></div><script type="text/javascript" src="https://oap.accuweather.com/launch.js"></script>
<div style="text-align:center;padding:1em 0;"> <h4><a style="text-decoration:none;" href="https://www.zeitverschiebung.net/en/timezone/europe--sarajevo"><span style="color:gray;">Current local time in</span><br />Europe/Sarajevo</a></h4> <iframe src="https://www.zeitverschiebung.net/clock-widget-iframe-v2?language=en&size=small&timezone=Europe%2FSarajevo" width="100%" height="90" frameborder="0" seamless></iframe> </div>
        </div>
        <div id="footer">
                <a href="https://www.facebook.com/Omladinski-savjet-Isto%C4%8Dna-Ilid%C5%BEa-126475727404920/?ref=br_rs"><i class="fab fa-facebook"></i></a>
                <a href="mailto:jannikola@gmail.com"><i class="far fa-envelope"></i></a>
                <i class="fas fa-phone"></i>
        </div>
    </div>
    <!--
    <script>
    function sort(){
        $("#summx").tsort("",{attr:"id"});
    }
    sort();
    </script>
    -->
    <!--<script src="myscript2.js"></script>-->
</body>
</html>
